title: django tutorial
date: 2016-03-20 19:55:46
categories: T
tags: [python, django]
---
### 下载django
```bash
pip install django==1.8.11
```

### 建立django项目
```bash
django-admin.py startproject mysite
```

### 建立django应用
```bash
python manage.py startapp blog
```
