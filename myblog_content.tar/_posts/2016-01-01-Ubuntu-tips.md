title: 怎样在Ubuntu服务器上设置时区？
date: 2016-01-01 20:38:34
categories: T
tags: [ubuntu,tips]
---
你可以用这个命令看下服务器上当前的时区

```bash
$ date
```

或者看下时区文件

```bash
$ more /etc/timezone
```
 

 想要改变时区，运行这个就命令就可以。

```bash
$ sudo dpkg-reconfigure tzdata
```

 然后按照屏幕上的指示操作即可选择 Asia 然后Shanghai 即可
 记得重启下cron。
 
```bash
$ /etc/init.d/cron stop
$ /etc/init.d/cron start
```

或者这2个命令，他们等价。

```bash
$ stop cron
$ start cron
```