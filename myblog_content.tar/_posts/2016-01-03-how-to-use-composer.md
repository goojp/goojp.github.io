title: 关于使用composer
date: 2016-01-03 20:45:27
categories: T
tags: [php, composer]
---

在Python中，用pip感觉很方便，比如安装Flask框架,可以这样

```bash
$ pip install Flask
```

PHP也有类似的工具，叫做composer。 它不仅可以用来安装第三方的组件，还可以管理自动加载。


### 安装Composer
在Ubuntu上打开命令行（ctrl+atl+t快捷键），然后输入：

```bash
$ curl -sS https://getcomposer.org/installer | php
```

然后运行这个命令，

```bash
$ sudo mv composer.phar /usr/local/bin/composer
```

### 使用Composer安装组件

像下面这样使用Composer来安装一些组件的

```bash
$ composer require slim/slim  
```

创建项目
```bash
composer create-project laravel/laravel [blog] "5.1.*"
```
安装composer.json里面定义的依赖
```bash
composer install
```
升级依赖
```bash
composer update
```
重新自动加载
```bash
composer dump-autoload [--optimize]
```
升级composer
```bash
composer self-update
```


