title: 在Ubuntu上安装Google中文输入法
date: 2016-01-04 18:33:54
categories: T
tags: [tips, ubuntu]
---

我用的是Ubuntu 14.04 64版。一直是尽量用英文，所以也没装中文输入法。写博客，会换到
Win8上。现在决定在Ubuntu上写博客了，所以得装中文输入法。 在此记录下。

```bash
sudo apt-get install fcitx-googlepinyin
im-config
```

选择fcitx.
以上完了后，重启电脑。 点击电脑右上角的键盘图标， 选择“ Configure Current Input Method”。
点击“+”来添加一个新的语言，反选“Only show current language”，输入 Google-Pinyin。选择OK。
用Ctrl+Space 来切换输入法.


这是原文链接[Install Google Pinyin on Ubuntu 14.04](https://rivercitylabs.org/install-google-pinyin-on-ubuntu-14-04/安装输入法)